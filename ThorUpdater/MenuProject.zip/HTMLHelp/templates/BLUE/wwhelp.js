function SeeAlsoButton() 
{
   SeeAlso = document.all.SeeAlsoTopics;
   if (SeeAlso.style.display == 'none')
      SeeAlso.style.display='';
   else
      SeeAlso.style.display='none';
}
