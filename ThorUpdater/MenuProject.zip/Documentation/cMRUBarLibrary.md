﻿# cMRUBarLibrary

The library containing the class specified in [cMRUBarClass](cMRUBarClass.md) (this is a property of [SFPad](Class%20SFPad.md) and [SFBar](Class%20SFBar.md) because bars can have submenus).

See [lMRU](lMRU.md) for a description of MRU bars. This property defaults to SFMenu.vcx.
