﻿# cAppObjectName

The name of the variable containing the application object. This is a property of [SFBar](Class%20SFBar.md) and SFPadCommand.

This property is only used if [cAppObjectMethod](cAppObjectMethod.md) is filled in.
