﻿# cAppObjectMethod

The method of the application object to execute. This is a property of [SFBar](Class%20SFBar.md) and SFPadCommand.

Fill this in if the action to take when the bar is selected is to call a method of the application object whose name is stored in [cAppObjectName](cAppObjectName.md).
