﻿# nBarNumber

The number of the bar.

This is either assigned the value of the tnBarNumber parameter passed to the [AddBar](AddBar.md) method that created the bar or is automatically assigned to the next available position if tnBarNumber isn't specified.

## See Also

[Class SFBar](Class%20SFBar.md)