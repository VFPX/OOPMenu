﻿# Execute

Performs the action of a menu or toolbar function.

## Syntax

```foxpro
o.Execute()
```

## See Also

[SFMenuFunction](Class%20SFMenuFunction.md)