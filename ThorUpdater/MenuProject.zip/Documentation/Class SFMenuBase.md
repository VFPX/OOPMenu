﻿# Class SFMenuBase

**Parent Class: Collection**  

The base class for all other menu classes. Not used directly.

## Methods


| Member  | Description                              |
|---------|------------------------------------------|
| Release | Releases this object and all members of the collection. |

