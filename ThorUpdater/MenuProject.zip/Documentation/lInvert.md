﻿# lInvert

.T. to make this an inverted bar.

Inverted bars don't appear in the menu unless the [lMRU](lMRU.md) property of the pad they're in is .T. and the user selected the MRU bar at the bottom of the popup for the pad. This is used to create adaptive menus such as those in Microsoft Office applications. It's up to you to decide which bars should be inverted and whether bar become inverted or uninverted over time.

## See Also

[Class SFBar](Class%20SFBar.md)