﻿# AddSeparatorBar

Adds a separator bar to the pad or bar (this is a method of [SFPad](Class%20SFPad.md) and [SFBar](Class%20SFBar.md) because bars can have submenus).

An instance of SFSeparatorBar is added at the next available bar position in the popup.

## Syntax

```foxpro
o.AddSeparatorBar()
```
