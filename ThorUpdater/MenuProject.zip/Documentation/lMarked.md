﻿# lMarked

.T. if the bar is marked.

## Example

```foxpro
oMenu.ToolsPad.UsersBar.lMarked = .T.
```

## See Also

[Class SFBar](Class%20SFBar.md)