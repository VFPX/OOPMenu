﻿# lNoExecute

.T. if the implementation object is used to control the enabled or visible status of the menu item but not its execution.

## See Also

[SFMenuFunction](Class%20SFMenuFunction.md)