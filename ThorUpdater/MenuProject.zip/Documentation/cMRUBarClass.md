﻿# cMRUBarClass

The class to use for the MRU bar (this is a property of [SFPad](Class%20SFPad.md) and [SFBar](Class%20SFBar.md) because bars can have submenus).

See [lMRU](lMRU.md) for a description of MRU bars. This property defaults to [SFMRUBar](Class%20SFMRUBar.md).

## See Also

[lMRUBarLibrary](lMRUBarLibrary.md)