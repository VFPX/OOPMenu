﻿# cPadPosition

An optional "before" or "after" pad clause to use in defining the pad's location in the menu.

## Example

```foxpro
oMenu.ToolsPad.cPadPosition = 'after EditPad'
```

## See Also

[Class SFPad](Class%20SFPad.md)  
