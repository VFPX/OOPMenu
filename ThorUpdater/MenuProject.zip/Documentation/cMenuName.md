﻿# cMenuName

Specifies the name of the menu.

The default is "_msysmenu".

## Example

```foxpro
oMenu.cMenuName = 'MyMenu'
```

## See Also

[Class SFMenu](Class%20SFMenu.md)