﻿# ClearMenu

Releases the existing shortcut menu.

## See Also
[Class SFShortcutMenu](Class%20SFShortcutMenu.md)