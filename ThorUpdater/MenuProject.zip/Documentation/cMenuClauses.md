﻿# cMenuClauses

Other clauses for bar; see the VFP help topic for DEFINE BAR for a list of possible clauses.

## Example

```foxpro
oMenu.ToolsPad.UsersBar.cMenuClauses = [font 'Courier', 12]
```

## See Also

[Class SFBar](Class%20SFBar.md)